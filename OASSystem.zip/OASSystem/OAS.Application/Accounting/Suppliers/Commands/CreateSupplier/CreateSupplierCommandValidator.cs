using FluentValidation;
using OAS.Contracts.Accounting.Enums;
namespace OAS.Application.Accounting.Suppliers.Commands.CreateSupplier;
public sealed class CreateSupplierCommandValidator:AbstractValidator<CreateSupplierCommand>
{
    public CreateSupplierCommandValidator()
    {
        RuleFor(x=>x.Request.SupplierCode).MaximumLength(32);
        RuleFor(x=>x.Request.ParentAccountId).NotEmpty();
        RuleFor(x=>x.Request.EntityType).Must(x=>x!=PartyEntityType.Unknown && Enum.IsDefined(x));
        RuleFor(x=>x.Request.SupplierScope).Must(x=>x!=SupplierScope.Unknown && Enum.IsDefined(x));
        RuleFor(x=>x.Request.NameAr).NotEmpty().MaximumLength(150);
        RuleFor(x=>x.Request.NameEn).MaximumLength(150); RuleFor(x=>x.Request.TradeName).MaximumLength(150);
        RuleFor(x=>x.Request.NationalId).MaximumLength(50); RuleFor(x=>x.Request.CommercialRegistrationNo).MaximumLength(50); RuleFor(x=>x.Request.TaxNumber).MaximumLength(50);
        RuleFor(x=>x.Request.PreferredContactMethod).Must(x=>x!=ContactMethod.Unspecified && Enum.IsDefined(x)); RuleFor(x=>x.Request.CreditLimit).GreaterThanOrEqualTo(0); RuleFor(x=>x.Request.PaymentTermDays).GreaterThanOrEqualTo(0);
        RuleFor(x=>x.Request.DefaultLeadTimeDays).GreaterThanOrEqualTo(0).When(x=>x.Request.DefaultLeadTimeDays.HasValue); RuleFor(x=>x.Request.Notes).MaximumLength(1000);
    }
}
